// const mysql = require("mysql2");


// console.log("DATABASE CONNECTING...")
// const pool = mysql.createPool({
//   host:"127.0.0.1",
//   user:"root",
//   database:"WSA",
//   password:"123456",
//   port:'3307'
// }).promise();
// console.log("DATABASE CONNECTED...")

// module.exports = pool;